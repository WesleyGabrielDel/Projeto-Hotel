#Importar o flask e o os
from flask import Flask, send_from_directory   
import os, openpyxl #Biblioteca para ler arquivos Excel
from datetime import (
    datetime,
)
      
#Obter o caminho base do projeto, o caminho da pasta Front e o caminho da pasta static para conseguir usar os arquivos CSS
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..')) 
FRONTEND_DIR = os.path.join(BASE_DIR, 'front-end')
STATIC_DIR = os.path.join(FRONTEND_DIR, 'static')

#Obter o caminho do Banco de Dados e do arquivo Excel para ler os dados dos clientes
DB_DIR = os.path.join(os.path.dirname(__file__), '..', 'DB')
EXCEL_FILE = os.path.join(DB_DIR, 'clientes.xlsx')

#Criação das colunas do banco de dados (Linha 1)
COLUMNS = ["ID", "Nome", "CPF", "Email", "Telefone", "Endereço", "Observações", "Data Cadastro"]

#Verificação se o arquivo do DB existe. Se não existir ele cria o arquivo

#Criar o server (Os parâmetros permitem utilizar o css)
app = Flask(__name__, static_folder=STATIC_DIR, static_url_path="/" + STATIC_DIR)

#Criar a route da página, no caso a raiz/home
@app.route("/")                               
def home():
    return send_from_directory(FRONTEND_DIR, "index.html") #Retornar o HTML                      

#Página de Consulta
@app.route("/consulta")                               
def consulta_page():
    return send_from_directory(FRONTEND_DIR, "consulta.html") #Retornar o HTML      

#Página de Alterar
@app.route("/alterar")                               
def alterar_page():
    return send_from_directory(FRONTEND_DIR, "alterar.html") #Retornar o HTML 



if __name__ == "__main__":
    print("BASE_DIRECTORY:", BASE_DIR)
    print("FRONTEND_DIRECTORY:", FRONTEND_DIR)
    print("STATIC_DIRECTORY:", STATIC_DIR)
    app.run(debug=True);