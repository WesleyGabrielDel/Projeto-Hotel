from flask import Flask   #Importar o flask
app = Flask(__name__)     #Criar o server

@app.route('/')           #Criar a route da página, no caso a raiz
def home():
    return "Hello World!" #Retornar 

app.run(debug=True)