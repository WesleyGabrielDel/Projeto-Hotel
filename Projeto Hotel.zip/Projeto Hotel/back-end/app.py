#Importar o flask e o os
from flask import Flask, send_from_directory   
import os
      
#Obter o caminho base do projeto, o caminho da pasta Front e o caminho da pasta static para conseguir usar os arquivos CSS
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..')) 
FRONTEND_DIR = os.path.join(BASE_DIR, 'front-end')
STATIC_DIR = os.path.join(FRONTEND_DIR, 'static')

#Criar o server (Os parâmetros permitem utilizar o css)
app = Flask(__name__, static_folder=STATIC_DIR, static_url_path="/" + STATIC_DIR)

#Criar a route da página, no caso a raiz/home
@app.route("/")                               
def home():
    return send_from_directory(FRONTEND_DIR, "index.html") #Retornar o HTML                      

#Página de Consulta
@app.route("/consulta")                               
def consulta_page():
    return send_from_directory(FRONTEND_DIR, "consulta.html") #Retornar o HTML      

#Página de Alterar
@app.route("/alterar")                               
def alterar_page():
    return send_from_directory(FRONTEND_DIR, "alterar.html") #Retornar o HTML  

if __name__ == "__main__":
    print("BASE_DIRECTORY:", BASE_DIR)
    print("FRONTEND_DIRECTORY:", FRONTEND_DIR)
    print("STATIC_DIRECTORY:", STATIC_DIR)
    app.run(debug=True);